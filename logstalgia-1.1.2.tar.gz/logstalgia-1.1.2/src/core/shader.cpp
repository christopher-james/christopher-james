#include "shader.h"

#include "shader.cc"